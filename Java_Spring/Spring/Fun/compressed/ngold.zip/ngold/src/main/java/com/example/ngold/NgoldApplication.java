package com.example.ngold;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgoldApplication {

	public static void main(String[] args) {
		SpringApplication.run(NgoldApplication.class, args);
	}

}
