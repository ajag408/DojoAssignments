package com.codingdojo.zookeeper;

public class GorillaTest {

	public static void main(String[] args) {
		Gorilla gary = new Gorilla();
		gary.displayEnergy();
		gary.throwSomething();
		gary.throwSomething();
		gary.throwSomething();
		gary.eatBanana();
		gary.eatBanana();
		gary.climb();
		gary.displayEnergy();

	}

}
