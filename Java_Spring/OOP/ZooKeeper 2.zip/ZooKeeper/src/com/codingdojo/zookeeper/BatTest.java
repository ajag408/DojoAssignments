package com.codingdojo.zookeeper;

public class BatTest {

	public static void main(String[] args) {
		Bat burt = new Bat();
		burt.displayEnergy();
		burt.attackTown();
		burt.attackTown();
		burt.attackTown();
		burt.eatHumans();
		burt.eatHumans();
		burt.fly();
		burt.fly();
		burt.displayEnergy();
	}

}
