package com.codingdojo.zookeeper;

public class Mammal {
	protected int energyLevel;
	
	public int displayEnergy() {
		System.out.println(energyLevel);
		return energyLevel;
	}
}
