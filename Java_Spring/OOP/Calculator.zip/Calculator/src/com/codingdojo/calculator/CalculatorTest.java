package com.codingdojo.calculator;

public class CalculatorTest {

	public static void main(String[] args) {
		Calculator hung = new Calculator();
		hung.setOperandOne(10.5);

		hung.setOperation("+");

		hung.setOperandTwo(5.2);

		hung.performOperation();

		hung.getResults();

	}

}
