package com.codingdojo.calculator;

public class Calculator implements java.io.Serializable{
	private double op1;
	private double op2;
	private String op;
	private double result;
	
	public Calculator() {	
	}
	
	public void setOperandOne(double op1) {
		this.op1 = op1;
	}
	
	public void setOperandTwo(double op2) {
		this.op2 = op2;
	}
	
	public void setOperation(String op) {
		this.op = op;
	}
	
	public void performOperation() {
		if(op == "+") {
			result = op1 + op2;
		} else if(op == "-") {
			result = op1-op2;
		} else if (op == "*") {
			result = op1*op2;
		} else if (op == "/") {
			result = op1/op2;
		} else {
			System.out.println("Please enter valid operator");
		}
	}
	
	public void getResults() {
		System.out.println(result);
	}
}
