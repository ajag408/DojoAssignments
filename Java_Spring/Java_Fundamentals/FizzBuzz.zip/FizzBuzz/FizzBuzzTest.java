public class FizzBuzzTest {
    public static void main(String[] args) {
        FizzBuzz output = new FizzBuzz();
        String result = output.fizzBuzz(2);
        System.out.println(result);
    }
}
