//
//  ViewController.swift
//  NESW
//
//  Created by Akash Jagannathan on 3/19/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

class ViewController: UIViewController, DirectionViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let navigationController = segue.destination as! UINavigationController
        let controller = navigationController.topViewController as! DirectionViewController
        controller.delegate = self
        if segue.identifier == "North"{
            controller.content = "North"
        } else if segue.identifier == "South"{
            controller.content = "South"
        }else if segue.identifier == "West"{
            controller.content = "West"
        }else if segue.identifier == "East"{
            controller.content = "East"
        }
    }
    
    func directionViewController(by controller: DirectionViewController, didPressBackButton button: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }

}

