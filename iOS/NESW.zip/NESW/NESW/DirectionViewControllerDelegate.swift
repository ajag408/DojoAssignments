//
//  DirectionViewControllerDelegate.swift
//  NESW
//
//  Created by Akash Jagannathan on 3/19/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

protocol DirectionViewControllerDelegate: class{
    func directionViewController(by controller: DirectionViewController, didPressBackButton button: UIBarButtonItem)
}
