//
//  DirectionViewController.swift
//  NESW
//
//  Created by Akash Jagannathan on 3/19/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

class DirectionViewController: UIViewController{
    
    weak var delegate: DirectionViewControllerDelegate?
    
    var content: String?
    
    @IBOutlet weak var directionLabelContent: UILabel!
    
    @IBAction func BackButtonPressed(_ sender: UIBarButtonItem) {
        delegate?.directionViewController(by: self, didPressBackButton: sender)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        directionLabelContent.text = content
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }

    
}
