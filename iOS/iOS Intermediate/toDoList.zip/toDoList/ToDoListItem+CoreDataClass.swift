//
//  ToDoListItem+CoreDataClass.swift
//  toDoList
//
//  Created by Akash Jagannathan on 3/23/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import Foundation
import CoreData

@objc(ToDoListItem)
public class ToDoListItem: NSManagedObject {

}
