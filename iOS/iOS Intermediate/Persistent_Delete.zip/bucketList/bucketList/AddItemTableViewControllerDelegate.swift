//
//  SaveButtonDelegate.swift
//  bucketList
//
//  Created by Akash Jagannathan on 3/18/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit
import Foundation
protocol AddItemTableViewControllerDelegate: class {
    func addItemViewController(by controller: AddItemTableViewController, didEditItem item: String, indexPath: NSIndexPath)
    func addItemViewController(by controller: AddItemTableViewController, didFinishAddingItem item: String)
    func addItemViewController(by controller: AddItemTableViewController, didPressCancelButton button: UIBarButtonItem) // Taken from CancelButtonDelegate file, and altered to match pattern.
    // NOTE: You will need to update AddItemTableViewController to make the Cancel Button work
}
