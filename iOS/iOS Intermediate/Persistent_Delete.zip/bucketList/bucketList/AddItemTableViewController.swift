//
//  AddItemTableViewController.swift
//  bucketList
//
//  Created by Akash Jagannathan on 3/18/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

class AddItemTableViewController: UITableViewController{
   
    weak var delegate: AddItemTableViewControllerDelegate?
    
    var item: String?
    var index: NSIndexPath?
    
    @IBOutlet weak var itemTextField: UITextField!
    
    @IBAction func cancelBarButtonPressed(_ sender: UIBarButtonItem) {
//        delegate?.addItemViewController(by: self, didPressCancelButton: sender)
        delegate?.addItemViewController(by: self, didPressCancelButton: sender)
    }
    
    @IBAction func saveBarButtonPressed(_ sender: UIBarButtonItem) {
        let text = itemTextField.text!
        if let indexPath = index {
            delegate?.addItemViewController(by: self, didEditItem: text, indexPath: indexPath)
        }
        else{
            delegate?.addItemViewController(by: self, didFinishAddingItem: text)
        }

    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        itemTextField.text = item
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
