//
//  EditContactViewController.swift
//  ContactList
//
//  Created by Akash Jagannathan on 3/24/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

class EditContactViewController: UIViewController{
    
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var number: UITextField!
    weak var delegate: EditContactViewControllerDelegate?
    var index_var: NSIndexPath!
    
    var firstNameFiller: String!
    var lastNameFiller: String!
    var numberFiller: String!
    
    @IBAction func saveButtonPressed(_ sender: UIBarButtonItem) {
        delegate?.editContactViewController(by: self, firstName: firstName.text!, lastName: lastName.text!, number: number.text!, indexPath: index_var)
    }
    
    @IBAction func cancelButtonPressed(_ sender: UIBarButtonItem) {
        delegate?.editContactViewController(by: self, cancelButtonPressedBy: sender)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        firstName.text = firstNameFiller
        lastName.text = lastNameFiller
        number.text = numberFiller
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
