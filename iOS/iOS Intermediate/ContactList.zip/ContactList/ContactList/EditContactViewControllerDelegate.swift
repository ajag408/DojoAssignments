//
//  EditContactViewControllerDelegate.swift
//  ContactList
//
//  Created by Akash Jagannathan on 3/24/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

protocol EditContactViewControllerDelegate: class{
    func editContactViewController(by controller: EditContactViewController, cancelButtonPressedBy button: UIBarButtonItem)
    func editContactViewController(by controller: EditContactViewController, firstName: String, lastName: String, number: String, indexPath: NSIndexPath)
}
