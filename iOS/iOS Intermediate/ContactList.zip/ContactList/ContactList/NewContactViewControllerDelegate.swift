//
//  NewContactViewControllerDelegate.swift
//  ContactList
//
//  Created by Akash Jagannathan on 3/24/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

protocol NewContactViewControllerDelegate: class{
    func newContactViewController(by controller: NewContactViewController, didPressCancelButton button: UIBarButtonItem)
    func newContactViewController(by controller: NewContactViewController, firstName: String, lastName: String, number: String)
}
