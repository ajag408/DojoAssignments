//
//  ViewContactViewController.swift
//  ContactList
//
//  Created by Akash Jagannathan on 3/24/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

class ViewContactViewController: UIViewController{
    
//    var contact: String?
//    var index: NSIndexPath?
    
    weak var delegate: ViewContactViewControllerDelegate?
    @IBOutlet weak var numberField: UILabel!
    @IBOutlet weak var nameField: UILabel!
    
    @IBAction func DoneButtonPressed(_ sender: UIBarButtonItem) {
        delegate?.viewContactViewController(by: self, didPressDoneButton: sender)
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
