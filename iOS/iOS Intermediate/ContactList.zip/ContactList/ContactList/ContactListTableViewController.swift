//
//  ViewController.swift
//  ContactList
//
//  Created by Akash Jagannathan on 3/24/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit
import CoreData

class ContactListTableViewController: UITableViewController, NewContactViewControllerDelegate, ViewContactViewControllerDelegate, EditContactViewControllerDelegate{
    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var contacts = [ContactItem]()

    override func viewDidLoad() {
        super.viewDidLoad()
        FetchAllItems()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func FetchAllItems(){
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "ContactItem")
        do{
            let results = try managedObjectContext.fetch(request)
            contacts = results as! [ContactItem]
        } catch {
            print(error)
        }
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactListCell", for: indexPath)
        
        cell.textLabel?.text = contacts[indexPath.row].firstName! + " " + contacts[indexPath.row].lastName!
        
        cell.detailTextLabel?.text = contacts[indexPath.row].number

    
        return cell
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alertController = UIAlertController(title: "", message: "", preferredStyle: .actionSheet)
        
        let viewButton = UIAlertAction(title: "View", style: .default, handler: { (action) -> Void in
            self.performSegue(withIdentifier: "viewContact", sender: indexPath)
            })
        
        let editButton = UIAlertAction(title: "Edit", style: .default, handler: { (action) -> Void in
            self.performSegue(withIdentifier: "editContact", sender: indexPath)
        })
        
        let deleteButton = UIAlertAction(title: "Delete", style: .destructive, handler: { (action) -> Void in
            self.managedObjectContext.delete(self.contacts[indexPath.row])
            do{
                try self.managedObjectContext.save()
            }catch{
                print(error)
            }
            self.FetchAllItems()
            tableView.reloadData()
            })
        
        let cancelButton = UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) -> Void in
            print("Cancel button tapped")
        })
        
        alertController.addAction(viewButton)
        alertController.addAction(editButton)
        alertController.addAction(deleteButton)
        alertController.addAction(cancelButton)
        
        present(alertController, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "newContactSegue"{
            let navigationController = segue.destination as! UINavigationController
            let controller = navigationController.topViewController as! NewContactViewController
            controller.delegate = self
        } else if segue.identifier == "viewContact"{
                let navigationController = segue.destination as! UINavigationController
                let controller = navigationController.topViewController as! ViewContactViewController
                controller.delegate = self
                print(sender)
                let indexPath = sender as! NSIndexPath
                let contact = contacts[indexPath.row]
                controller.nameField.text = contact.firstName! + " " + contact.lastName!
                controller.numberField.text = contact.number
        } else if segue.identifier == "editContact"{
            let navigationController = segue.destination as! UINavigationController
            let controller = navigationController.topViewController as! EditContactViewController
            controller.delegate = self
            print(sender)
            let indexPath = sender as! NSIndexPath
            let contact = contacts[indexPath.row]
            controller.index_var = indexPath
            controller.firstNameFiller = contact.firstName
            controller.lastNameFiller = contact.lastName
            controller.numberFiller = contact.number
        }
    }
    
    func newContactViewController(by controller: NewContactViewController, didPressCancelButton button: UIBarButtonItem){
        dismiss(animated: true, completion: nil)
    }
    
    func newContactViewController(by controller: NewContactViewController, firstName: String, lastName: String, number: String){
        let newItem = ContactItem(context: managedObjectContext)
        newItem.firstName = firstName
        newItem.lastName = lastName
        newItem.number = number
        do{
            try managedObjectContext.save()
        }catch{
            print(error)
        }
        FetchAllItems()
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
    
    func viewContactViewController(by controller: ViewContactViewController, didPressDoneButton button: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }

    func editContactViewController(by controller: EditContactViewController, cancelButtonPressedBy button: UIBarButtonItem) {

        dismiss(animated: true, completion: nil)
    }
    
    func editContactViewController(by controller: EditContactViewController, firstName: String, lastName: String, number: String, indexPath: NSIndexPath) {
        contacts[indexPath.row].firstName = firstName
        contacts[indexPath.row].lastName = lastName
        contacts[indexPath.row].number = number
        do{
            try managedObjectContext.save()
        }catch{
            print(error)
        }
        FetchAllItems()
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
}

