//
//  ViewContactViewControllerDelegate.swift
//  ContactList
//
//  Created by Akash Jagannathan on 3/24/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

protocol ViewContactViewControllerDelegate: class{
    func viewContactViewController(by controller: ViewContactViewController, didPressDoneButton button: UIBarButtonItem)
}
