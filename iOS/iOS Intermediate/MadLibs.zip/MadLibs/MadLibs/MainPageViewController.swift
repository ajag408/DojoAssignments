//
//  ViewController.swift
//  MadLibs
//
//  Created by Akash Jagannathan on 3/19/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

class MainPageViewController: UIViewController, FormViewControllerDelegate {

    @IBOutlet weak var madlibSentence: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let controller = segue.destination as! FormViewController
        controller.delegate = self
    }

    func formViewController(by controller: FormViewController, didSubmit button: UIButton, blank1: String?, blank2: String?, blank3: String?, blank4: String?) {
        if let ublank1 = blank1, let ublank2 = blank2, let ublank3 = blank3, let ublank4 = blank4{
            madlibSentence.text = "We are having a perfectly \(ublank1) time for now.  Later we will \(ublank2) and \(ublank3) in \(ublank4)"
        }
        dismiss(animated: true, completion: nil)
    }

}

