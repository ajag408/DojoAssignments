//
//  FormViewController.swift
//  MadLibs
//
//  Created by Akash Jagannathan on 3/19/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

class FormViewController: UIViewController{
    
    weak var delegate: FormViewControllerDelegate?
    
    
    @IBOutlet weak var adjTextField: UITextField!
    
    @IBOutlet weak var verb1TextField: UITextField!
    
    @IBOutlet weak var verb2TextField: UITextField!
    
    @IBOutlet weak var nounTextField: UITextField!
    
    @IBAction func submitButtonPressed(_ sender: UIButton) {
        let blank1 = adjTextField.text
        let blank2 = verb1TextField.text
        let blank3 = verb2TextField.text
        let blank4 = nounTextField.text
        
        delegate?.formViewController(by: self, didSubmit: sender, blank1: blank1, blank2: blank2, blank3: blank3, blank4: blank4)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        adjTextField.placeholder = "Adjective"
        verb1TextField.placeholder = "Verb"
        verb2TextField.placeholder = "Verb"
        nounTextField.placeholder = "Noun"
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
}
