//
//  FormViewControllerDelegate.swift
//  MadLibs
//
//  Created by Akash Jagannathan on 3/19/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

protocol FormViewControllerDelegate: class{
    func formViewController(by controller: FormViewController, didSubmit button: UIButton, blank1: String?, blank2: String?, blank3: String?, blank4: String?)
}
