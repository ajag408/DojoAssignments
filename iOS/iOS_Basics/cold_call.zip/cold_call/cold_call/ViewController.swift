//
//  ViewController.swift
//  cold_call
//
//  Created by Akash Jagannathan on 3/9/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var nameView: UILabel!

    var names = ["Johnny", "BehenChoth", "T-Bone", "Jerm", "Face", "Steef", "Redart", "Slem"]
    
    @IBAction func coldCallPressed(_ sender: UIButton) {
        let randIndex = arc4random_uniform(UInt32(names.count)) - 1
        print(randIndex)
        nameView.text = names[Int(randIndex)]
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        nameView.text = names[0]
        // Do any additional setup after loading the view, typically from a nib.
    }
    
//    func updateUI(){
//        let rand1 = arc4random_uniform(UInt32(names.count)) - 1
//        nameView.text = names[Int(rand1)]
//    }
//
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

