//
//  ViewController.swift
//  GNG
//
//  Created by Akash Jagannathan on 4/2/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var num = String(arc4random_uniform(99) + 1)

    
    @IBOutlet weak var guess: UITextField!
    
    @IBAction func submitButtonPressed(_ sender: UIButton) {
        print(num)
        if guess.text! == num{
            print("Correct!")
            let alert = UIAlertController(title: "Correct!", message: "Well done", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Play Again", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            num = String(arc4random_uniform(99)+1)
        } else {
            let guessNum = Int(guess.text!)
            let numNum = Int(num)
            if guessNum! < numNum!{
                let alert = UIAlertController(title: "Inorrect!", message: "Too Low", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Guess Again", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            } else if guessNum! > numNum! {
                let alert = UIAlertController(title: "Inorrect!", message: "Too High", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Guess Again", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

