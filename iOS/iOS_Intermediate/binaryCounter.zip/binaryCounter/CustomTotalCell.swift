//
//  CustomTotalCell.swift
//  binaryCounter
//
//  Created by Akash Jagannathan on 3/21/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

class CustomTotalCell: UITableViewCell{
    @IBOutlet weak var totalLabel: UILabel!
    
}
