//
//  CustomNumCellDelegate.swift
//  binaryCounter
//
//  Created by Akash Jagannathan on 3/21/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

protocol CustomNumCellDelegate: class{
    func customNumCell(by controller: CustomNumCell, didPressAddButton: UIButton, addVal: Int)
    func customNumCell(by controller: CustomNumCell, didPressSubtractButton: UIButton, subVal: Int)
}
