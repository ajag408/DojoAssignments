//
//  CustomNumCell.swift
//  binaryCounter
//
//  Created by Akash Jagannathan on 3/21/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

class CustomNumCell: UITableViewCell{
    
    weak var delegate: CustomNumCellDelegate?
    
    @IBAction func addButton(_ sender: UIButton) {
        let addVal = Int(tenPower.text!)!
        delegate?.customNumCell(by: self, didPressAddButton: sender, addVal: addVal)

    }
    

    
    @IBAction func subtractButton(_ sender: UIButton) {
        let subVal = Int(tenPower.text!)!
        delegate?.customNumCell(by: self, didPressSubtractButton: sender, subVal: subVal)
    }

    
    

    
    

    

    
    

    @IBOutlet weak var tenPower: UILabel!
}
