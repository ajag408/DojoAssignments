//
//  Dog+CoreDataClass.swift
//  myDogs
//
//  Created by Akash Jagannathan on 4/1/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import Foundation
import CoreData

@objc(Dog)
public class Dog: NSManagedObject {

}
