//
//  ViewController.swift
//  bucketList
//
//  Created by Akash Jagannathan on 3/18/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//

import UIKit

class bucketListViewController: UITableViewController,AddItemTableViewControllerDelegate {

    
    var items = ["Be happy", "Develop practice", "Gain knowledge"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // dequeue the cell from our storyboard
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell")!
        // All UITableViewCell objects have a build in textLabel so set it to the model that is corresponding to the row in array
        cell.textLabel?.text = items[indexPath.row]
        // return cell so that Table View knows what to draw in each row
        return cell
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        items.remove(at: indexPath.row)
        tableView.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        performSegue(withIdentifier: "EditItem", sender: indexPath)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AddItem" {
            let navigationController = segue.destination as! UINavigationController
            let controller = navigationController.topViewController as! AddItemTableViewController
            controller.delegate = self
        } else if segue.identifier == "EditItem" {
            let navigationController = segue.destination as! UINavigationController
            let controller = navigationController.topViewController as! AddItemTableViewController
            controller.delegate = self
            let indexPath = sender as! NSIndexPath
            let item = items[indexPath.row]
            controller.index = indexPath
            controller.item = item
            
        }
    }
    
    func addItemViewController(by controller: AddItemTableViewController, didEditItem item: String, indexPath: NSIndexPath) {
        
        items[indexPath.row] = item
        tableView.reloadData()
        dismiss(animated: true, completion: nil)

    }
    
    func addItemViewController(by controller: AddItemTableViewController, didFinishAddingItem item: String) {
        
        items.append(item)
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
        
    }
    func addItemViewController(by controller: AddItemTableViewController, didPressCancelButton button: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }

}

