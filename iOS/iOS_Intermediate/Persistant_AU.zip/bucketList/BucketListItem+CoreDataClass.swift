//
//  BucketListItem+CoreDataClass.swift
//  bucketList
//
//  Created by Akash Jagannathan on 3/20/17.
//  Copyright © 2017 Akash Jagannathan. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData

@objc(BucketListItem)
public class BucketListItem: NSManagedObject {

}
