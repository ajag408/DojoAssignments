
// const header = React.createElement('h1', null, 'Hello Dojo!');
ReactDOM.render(React.createElement("div", null, React.createElement('h1', null, 'Hello Dojo!'),
    React.createElement('h3', null, 'Goals:'),
    React.createElement('ul', null,
        React.createElement('li', null, 'Be happpy'), React.createElement('li', null, 'Null'),
      React.createElement('li', null, 'Null'), React.createElement('li', null, 'Null'))), document.getElementById('app'));
// ReactDOM.render(React.createElement('h1', null, 'Hello Dojo!'), document.getElementById('app'));
// ReactDOM.render(React.createElement('h3', null, 'Goals:'), document.getElementById('app'));
// ReactDOM.render(React.createElement('ul', null,
//     React.createElement('li', null, 'Be happpy'), React.createElement('li', null, 'Null'),
//   React.createElement('li', null, 'Null'), React.createElement('li', null, 'Null')), document.getElementById('app'));
