console.log("future routes");
// var friends = require('../controllers/friends.js');
module.exports = function(app){
  // app.get('/', function(req, res) {
  //   friends.renderIndex(req,res)
  })
