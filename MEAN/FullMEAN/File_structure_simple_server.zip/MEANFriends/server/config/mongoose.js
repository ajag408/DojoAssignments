console.log("future mongoose connection and model loading");

// // require mongoose
// var mongoose = require('mongoose');
// // require the fs module for loading model files
// var fs = require('fs');
// // require path for getting the models path
// var path = require('path');
// // connect to mongoose!
