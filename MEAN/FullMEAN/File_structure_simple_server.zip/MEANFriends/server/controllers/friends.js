module.exports = {
  renderIndex: function(req, res){
    res.render('index.html');
  }
}
