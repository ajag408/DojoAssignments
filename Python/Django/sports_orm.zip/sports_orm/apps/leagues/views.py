from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	# baseball = League.objects.filter(sport="Baseball")
 #  	print(baseball)
	# context = {
	# 	"leagues": baseball,
	# }


	# leagues = League.objects.filter(name__contains="women")
	# print("QUERY RESULT:", leagues)
	# context = {
	# 	"leagues": leagues
	# }

	# hockey = League.objects.filter(name__contains='hockey')
	# context = {
	# 	"leagues": hockey
	# }

	# not_football = League.objects.exclude(name__contains="football")
 #  	context = {
	# 	'leagues': not_football
	# }

	# conference = League.objects.filter(name__contains='conference')
	# context={
	# 	'leagues': conference
	# }

	# atlantic = League.objects.filter(name__contains='atlantic')
	# context = {
	# 	'leagues': atlantic
	# }

	# dallas = Team.objects.filter(location = 'Dallas')
	# print(dallas)
	# context = {
	# 	'teams': dallas
	# }

	# raptors = Team.objects.filter(team_name = 'Raptors')
	# context={
	# 	'teams': raptors
	# }

	# city = Team.objects.filter(location__contains = 'City')
	# context={
	# 	'teams': city
	# }

	# t_start = Team.objects.filter(team_name__startswith='T')
	# context={
	# 	'teams': t_start
	# }

	# location = Team.objects.all()
	# context ={
	# 	'teams': location
	# }

	# name_reverse = Team.objects.all()
	# context ={
	# 	'teams': name_reverse
	# }

	# cooper = Player.objects.filter(last_name = 'Cooper')
	# context = {
	# 	'players': cooper
	# }

	# joshua = Player.objects.filter(first_name = 'Joshua')
	# context = {
	# 	'players': joshua
	# }

	# exclude = Player.objects.filter(last_name='Cooper').exclude(first_name='Joshua')
	# context={
	# 	'players': exclude
	# }


	name_or = Player.objects.filter(first_name = 'Alexander')|Player.objects.filter(first_name = 'Wyatt')
	context={
		'players': name_or
	}

	# context = {
	# 	"leagues": League.objects.all(),
	# 	"teams": Team.objects.all(),
	# 	"players": Player.objects.all(),
	# }
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
