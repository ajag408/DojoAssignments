from __future__ import unicode_literals

from django.apps import AppConfig


class RandomWordGConfig(AppConfig):
    name = 'random_word_g'
