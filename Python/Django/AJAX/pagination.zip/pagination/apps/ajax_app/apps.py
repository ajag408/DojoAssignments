from __future__ import unicode_literals

from django.apps import AppConfig


class AjaxAppConfig(AppConfig):
    name = 'ajax_app'
